"""Memecoin Radar backend."""
