"""The live data spine: streams in, prioritized polling, storage, push to UI."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any

import yaml

from .adapters import dexscreener as dsx
from .adapters import feeds
from .adapters.coinbase import Coinbase
from .adapters.dexscreener import DexScreener
from .adapters.extra import Extra
from .adapters.geckoterminal import GeckoTerminal
from .adapters.market import Market
from .adapters.chaintrades import ChainTrades, extra_urls
from .adapters.pumpportal import AltTrades, PumpPortal
from .adapters.rugcheck import RugCheck
from .config import settings
from .db import DB
from .detect import detect
from .hub import hub

log = logging.getLogger("radar.tracker")

TOKEN_SUMMARY_SQL = """
SELECT t.address, t.chain, t.name, t.symbol, t.image, t.source, t.launched_at, t.first_seen, t.graduated_at,
       t.boost_amount, t.has_profile, t.pump_mcap_sol, t.pump_mcap_as_of, t.deployer,
       p.pair_address, p.dex, p.url, p.price_usd, p.liquidity_usd, p.fdv, p.market_cap,
       p.vol_m5, p.vol_h1, p.vol_h6, p.vol_h24, p.buys_m5, p.sells_m5, p.buys_h1, p.sells_h1,
       p.buys_h24, p.sells_h24, p.chg_m5, p.chg_h1, p.chg_h6, p.chg_h24, p.pair_created_at, p.as_of,
       s.score_normalised AS rug_score, s.mint_authority, s.freeze_authority, s.lp_locked_pct, s.top10_pct,
       s.holders, s.rugged, s.as_of AS safety_as_of
FROM tokens t
LEFT JOIN pairs p ON p.pair_address = t.best_pair
LEFT JOIN safety_reports s ON s.token_address = t.address
"""


def _sources_cfg() -> dict[str, Any]:
    for p in (Path("../config/sources.yaml"), Path("config/sources.yaml"), Path("/app/config/sources.yaml")):
        if p.exists():
            return yaml.safe_load(p.read_text()) or {}
    return {}


# pump.fun bonding curve: starts with 30 virtual SOL, graduates when ~85 real SOL is in (≈115 virtual).
CURVE_START_SOL, CURVE_END_SOL = 30.0, 115.0


HIDE_MAYHEM = __import__("os").environ.get("HIDE_MAYHEM", "1") != "0"


def is_mayhem(m: dict[str, Any]) -> bool:
    """pump.fun Mayhem Mode launches (an AI agent trades them for 24h; 2B supply instead of 1B). PumpPortal has no
    documented flag, so: any `mayhem` field, else the supply implied by the create event (market cap / curve price)."""
    for k, v in m.items():
        if "mayhem" in str(k).lower() and v not in (None, False, 0, "", "false", "0"):
            return True
    try:
        vs, vt, mc = float(m["vSolInBondingCurve"]), float(m["vTokensInBondingCurve"]), float(m["marketCapSol"])
        return vs > 0 and vt > 0 and mc > 0 and mc / (vs / vt) > 1.5e9
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return False


def curve_progress(vsol: Any) -> float | None:
    try:
        return round(max(0.0, min(100.0, (float(vsol) - CURVE_START_SOL) / (CURVE_END_SOL - CURVE_START_SOL) * 100)), 1)
    except (TypeError, ValueError):
        return None


class Tracker:
    def __init__(self, db: DB) -> None:
        self.db = db
        self.dex = DexScreener()
        self.gecko = GeckoTerminal()
        self.rug = RugCheck()
        self.market = Market()
        self.pump = PumpPortal(self.on_create, self.on_trade, self.on_migrate)
        # free fallback when PumpPortal's trade stream is silent (it needs an API key since May 2026)
        self.chain = ChainTrades(self.on_trade, lambda: self.pump.token_subs, wallets=lambda: self.pump.account_subs)
        self.chain_task: asyncio.Task | None = None
        # more free public RPC websockets alongside it: each public node drops part of the tape, together they see more
        self.extras = [ChainTrades(self.on_trade, lambda: self.pump.token_subs, wallets=lambda: self.pump.account_subs, url=u,
                                   name=f"chaintrades{i + 2}") for i, u in enumerate(extra_urls())]
        self.extra_tasks: dict[int, asyncio.Task] = {}
        import os as _os
        self.alt = AltTrades(self.on_trade, _os.environ.get("PUMP_ALT_WS_URL", "wss://pumpdev.io/ws"))
        self.alt_task: asyncio.Task | None = None
        self.chain_since = 0.0
        self._sigs: set[str] = set()
        self._trade_rows: list[tuple] = []
        self._mcap_rows: dict[str, tuple] = {}
        self._flush_task: asyncio.Task | None = None
        self._sig_q: list[str] = []
        self.coinbase = Coinbase(self.on_tick)
        self.sol_usd: float | None = None
        self.trending_set: set[str] = set()
        self.boosted_set: set[str] = set()
        self.rug_queue: asyncio.Queue[str] = asyncio.Queue()
        self.rug_pending: set[str] = set()
        self.tasks: list[asyncio.Task] = []
        self.extra = Extra()
        self.flash_tokens: dict[str, float] = {}
        self.launch_watch: dict[str, float] = {}       # mint -> until (first-90s trade capture)
        self.born: dict[str, float] = {}               # mint -> launch time: newborns always get a trade subscription first
        # hooks wired by the app: trade(t), tokens(rows), safety(rep), social(event), custom(item)
        self.hooks: dict[str, list] = {"trade": [], "tokens": [], "safety": [], "social": [], "new_token": [], "news": [],
                                         "launch": [], "graduated": [], "trending_first": []}
        self.news_enricher: Any = None                 # NewsIntel.enrich(row, feed) -> tagged row; wired by the app
        self.feed_backoff: dict[str, tuple[int, float]] = {}   # feed name -> (consecutive failures, retry after)
        self.gecko_networks = [n.strip() for n in __import__("os").environ.get("GECKO_NETWORKS", "solana,base,bsc,eth").split(",") if n.strip()]
        self.poly_prev: dict[str, float] = {}
        self.subs_kick = asyncio.Event()               # set to re-evaluate trade subscriptions now (someone opened a token)
        self.trending_seen: set[str] = set()
        self.mayhem: set[str] = set()
        for c in (self.dex.http, self.gecko.http, self.rug.http):
            c.on_request = self._usage

    # ---------- lifecycle ----------
    def start(self) -> None:
        jobs = [self.pump.run(), self.coinbase.run(), self.scheduler(), self.rug_worker(), self.trade_subs_loop(), self.trade_feed_loop(),
                self.every(settings.gecko_trending_every, self.poll_gecko_trending),
                self.every(settings.gecko_new_every, self.poll_gecko_new, delay=7),
                self.every(settings.dex_profiles_every, self.poll_dex_profiles, delay=3),
                self.every(600, self.poll_fear_greed), self.every(600, self.poll_llama, delay=5),
                self.every(180, self.poll_cg_trending, delay=11), self.every(600, self.poll_cg_meme, delay=40),
                self.every(60, self.poll_polymarket, delay=2), self.every(120, self.poll_kalshi, delay=9),
                self.every(3600, self.prune, delay=60),
                self.every(120, self.poll_gecko_other, delay=30), self.every(300, self.poll_jupiter_recent, delay=13),
                self.every(3 * 3600, self.poll_calendar, delay=17)]
        cfg = _sources_cfg().get("rss") or {}
        for i, f in enumerate(cfg.get("feeds") or []):
            jobs.append(self.every(float(f.get("every_s") or cfg.get("every_s") or 60),
                                   lambda f=f: self.poll_feed(f), delay=i * 2))
        self.tasks = [asyncio.create_task(j) for j in jobs]

    async def stop(self) -> None:
        self.pump.stop()
        self.coinbase.stop()
        for t in self.tasks:
            t.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)

    async def every(self, seconds: float, fn, delay: float = 0) -> None:
        await asyncio.sleep(delay)
        while True:
            try:
                await fn()
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 - adapters record their own health; keep looping
                log.debug("job %s failed: %s", getattr(fn, "__name__", fn), e)
            await asyncio.sleep(seconds)

    def _usage(self, adapter: str, path: str, status: int, ms: float) -> None:
        asyncio.get_running_loop().create_task(
            self.db.exec("INSERT INTO api_usage (ts, adapter, path, status, latency_ms) VALUES (?,?,?,?,?)",
                         (time.time(), adapter, path.split("?")[0][:120], status, ms)))

    # ---------- streams ----------
    async def on_tick(self, tick: dict[str, Any]) -> None:
        if tick["symbol"] == "SOL":
            self.sol_usd = tick["price"]
        await self.db.upsert("market", {"key": f"px_{tick['symbol']}", "value": tick["price"], "source": "coinbase",
                                        "as_of": tick["as_of"], "data_json": json.dumps(tick)}, "key")
        await hub.publish("tick", tick)

    async def on_create(self, m: dict[str, Any]) -> None:
        now = time.time()
        mint = m.get("mint")
        if not mint:
            return
        try:  # pump.fun supply is 1B tokens; initialBuy is the dev's token amount in the create tx
            dev_pct = round(float(m.get("initialBuy") or 0) / 1e9 * 100, 2)
        except (TypeError, ValueError):
            dev_pct = None
        row = {"address": mint, "chain": "solana", "name": m.get("name"), "symbol": m.get("symbol"),
               "uri": m.get("uri"), "deployer": m.get("traderPublicKey"), "source": "pumpportal",
               "launched_at": now, "first_seen": now, "pump_mcap_sol": m.get("marketCapSol"),
               "pump_mcap_as_of": now, "updated": now, "dev_initial_buy_pct": dev_pct,
               "curve_sol": m.get("vSolInBondingCurve"), "curve_progress": curve_progress(m.get("vSolInBondingCurve"))}
        if is_mayhem(m):
            row["is_mayhem"] = 1
            self.mayhem.add(mint)
            await self.db.upsert("tokens", row, "address")
            if HIDE_MAYHEM:
                return     # stored (so it's never mistaken for a normal coin later) but not shown, scored or streamed
        await self.db.upsert("tokens", row, "address")
        await self._hook("new_token", row)
        await self._hook("launch", {**row, "initial_buy_sol": m.get("solAmount"), "initial_buy_tokens": m.get("initialBuy"),
                                    "vsol": m.get("vSolInBondingCurve"), "signature": m.get("signature")})
        # watch every launch's first 90s of trades (sniper / bundle detection), on the one shared socket
        self.launch_watch[mint] = now + 90
        self.born[mint] = now
        if self.pump.ws is not None and mint not in self.pump.token_subs:
            self.pump.token_subs.add(mint)
            if not self.pump.saving:
                await self.pump.send({"method": "subscribeTokenTrade", "keys": [mint]})
        await hub.publish("launch", {**row, "initial_buy_sol": m.get("solAmount"), "pool": m.get("pool"),
                                     "mcap_usd": self._usd(m.get("marketCapSol")), "signature": m.get("signature")})

    async def on_trade(self, m: dict[str, Any]) -> None:
        now = time.time()
        mint = m.get("mint")
        sig = m.get("signature")
        if sig:                                          # the same trade can arrive from PumpPortal AND the chain feed
            if sig in self._sigs:
                return
            self._sigs.add(sig)
            self._sig_q.append(sig)
            if len(self._sig_q) > 40000:
                for old in self._sig_q[:20000]:
                    self._sigs.discard(old)
                del self._sig_q[:20000]
        if HIDE_MAYHEM and mint in self.mayhem:
            return
        trade = {"mint": mint, "ts": now, "side": m.get("txType"), "sol": m.get("solAmount"),
                 "tokens": m.get("tokenAmount"), "trader": m.get("traderPublicKey"),
                 "mcap_sol": m.get("marketCapSol"), "signature": m.get("signature"), "sol_usd": self.sol_usd}
        self._trade_rows.append(tuple(trade.values()))
        trade["vsol"] = m.get("vSolInBondingCurve")
        trade["pool"] = m.get("pool")
        if m.get("marketCapSol") is not None:
            self._mcap_rows[mint] = (m.get("marketCapSol"), now, m.get("vSolInBondingCurve"), curve_progress(m.get("vSolInBondingCurve")), mint)
        # the sniper, the brain and the autopilot see the trade FIRST; the database write is batched (one transaction every
        # 0.25 s instead of two commits per trade) so a busy tape never queues up behind disk writes
        await self._hook("trade", trade)
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = asyncio.get_running_loop().create_task(self._flush_trades())
        elif len(self._trade_rows) >= 2000:
            await self._flush_now()
        mc_usd = self._usd(m.get("marketCapSol"))
        # pump.fun supply is fixed at 1B, so price = market cap / 1e9 (lets open charts update on every trade)
        await hub.publish_viewers("trade", {**trade, "usd": self._usd(m.get("solAmount")), "mcap_usd": mc_usd,
                                            "price_usd": mc_usd / 1e9 if mc_usd else None}, mint)

    async def _flush_trades(self) -> None:
        await asyncio.sleep(0.25)
        await self._flush_now()

    async def flush_trades(self) -> None:
        """Readers that show a coin's tape from the database call this first, so a trade is never 'missing' for 0.25 s."""
        if self._trade_rows or self._mcap_rows:
            await self._flush_now()

    async def _flush_now(self) -> None:
        rows, ups = self._trade_rows, self._mcap_rows
        self._trade_rows, self._mcap_rows = [], {}
        try:
            if rows:
                await self.db.many("INSERT OR IGNORE INTO pump_trades (mint, ts, side, sol, tokens, trader, mcap_sol, signature, sol_usd) "
                                   "VALUES (?,?,?,?,?,?,?,?,?)", rows)
            if ups:
                await self.db.many("UPDATE tokens SET pump_mcap_sol=?, pump_mcap_as_of=?, curve_sol=COALESCE(?, curve_sol), "
                                   "curve_progress=CASE WHEN graduated_at IS NOT NULL THEN 100 ELSE COALESCE(?, curve_progress) END "
                                   "WHERE address=?", list(ups.values()))
        except Exception as e:  # noqa: BLE001
            log.warning("trade batch write: %s", e)

    async def on_migrate(self, m: dict[str, Any]) -> None:
        mint = m.get("mint")
        if not mint:
            return
        now = time.time()
        await self.db.upsert("tokens", {"address": mint, "chain": "solana", "source": "pumpportal",
                                        "first_seen": now, "graduated_at": now, "graduated_pool": m.get("pool"),
                                        "updated": now}, "address")
        await self.db.exec("UPDATE tokens SET graduated_at=COALESCE(graduated_at, ?), curve_progress=100 WHERE address=?", (now, mint))
        self.queue_rug(mint)
        tok = await self.token_summary(mint)
        await hub.publish("graduated", tok or {"address": mint, "graduated_at": now})
        await self._hook("graduated", {"mint": mint, "ts": now, "pool": m.get("pool")})

    async def _hook(self, name: str, arg: Any) -> None:
        for fn in self.hooks.get(name, []):
            try:
                await fn(arg)
            except Exception as e:  # noqa: BLE001 - a consumer bug must never break ingestion
                log.warning("hook %s: %s", name, e)

    def _usd(self, sol: Any) -> float | None:
        try:
            return round(float(sol) * self.sol_usd, 2) if self.sol_usd and sol is not None else None
        except (TypeError, ValueError):
            return None

    # ---------- priority scheduler for DexScreener ----------
    async def universe(self) -> dict[str, tuple[int, str]]:
        """address -> (tier, chain). Lower tier = hotter = refreshed more often."""
        now = time.time()
        out: dict[str, tuple[int, str]] = {}

        def put(addr: str, tier: int, chain: str = "solana") -> None:
            if addr and (addr not in out or out[addr][0] > tier):
                out[addr] = (tier, chain)

        for r in await self.db.all("SELECT address, chain FROM tokens WHERE first_seen > ? AND source='pumpportal'",
                                   (now - settings.launch_track_minutes * 60,)):
            put(r["address"], 3, r["chain"])
        hot_since = now - settings.hot_track_hours * 3600
        for r in await self.db.all(
                "SELECT t.address, t.chain FROM tokens t LEFT JOIN pairs p ON p.pair_address=t.best_pair "
                "WHERE t.graduated_at > ? OR (t.first_seen > ? AND (t.boost_amount > 0 OR t.has_profile=1 "
                "OR t.source='geckoterminal' OR p.vol_m5 > 2000))", (hot_since, hot_since)):
            put(r["address"], 2, r["chain"])
        for a in self.trending_set | self.boosted_set:
            row = await self.db.one("SELECT chain FROM tokens WHERE address=?", (a,))
            put(a, 2, (row or {}).get("chain") or "solana")
        for r in await self.db.all("SELECT w.address, COALESCE(t.chain,'solana') chain FROM watchlist w "
                                   "LEFT JOIN tokens t ON t.address=w.address"):
            put(r["address"], 1, r["chain"])
        for a, until in list(self.flash_tokens.items()):
            if until < now:
                self.flash_tokens.pop(a, None)
                continue
            row = await self.db.one("SELECT chain FROM tokens WHERE address=?", (a,))
            put(a, 0, (row or {}).get("chain") or "solana")
        for a in hub.viewed_tokens():
            row = await self.db.one("SELECT chain FROM tokens WHERE address=?", (a,))
            put(a, 0, (row or {}).get("chain") or "solana")
        return out

    async def scheduler(self) -> None:
        last: dict[str, float] = {}
        while True:
            try:
                uni = await self.universe()
                now = time.time()
                due = [(tier, now - last.get(a, 0), a, chain) for a, (tier, chain) in uni.items()
                       if now - last.get(a, 0) >= settings.tier_intervals[tier]]
                if not due:
                    await asyncio.sleep(0.5)
                    continue
                due.sort(key=lambda d: (d[0], -d[1]))
                chain = due[0][3]
                batch = [a for _, _, a, c in due if c == chain][: dsx.BATCH]
                for a in batch:
                    last[a] = now
                await self.refresh(chain, batch)
                for a in list(last):
                    if a not in uni:
                        del last[a]
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.debug("scheduler: %s", e)
                await asyncio.sleep(2)

    async def refresh(self, chain: str, addrs: list[str]) -> None:
        pairs = await self.dex.tokens(chain, addrs)
        now = time.time()
        best: dict[str, tuple[dict[str, Any], dict[str, Any]]] = {}
        for p in pairs:
            row = dsx.parse_pair(p, now)
            tok = row["token_address"]
            if tok not in addrs or not row["pair_address"]:
                continue
            await self.db.upsert("pairs", row, "pair_address")
            if tok not in best or (row["liquidity_usd"] or 0) > (best[tok][0]["liquidity_usd"] or 0):
                best[tok] = (row, dsx.token_meta(p))
        for tok, (row, meta) in best.items():
            await self.db.exec(
                "UPDATE tokens SET best_pair=?, last_refresh=?, updated=?, name=COALESCE(name, ?), symbol=COALESCE(symbol, ?), "
                "image=COALESCE(?, image), links_json=COALESCE(?, links_json), launched_at=COALESCE(launched_at, ?) WHERE address=?",
                (row["pair_address"], now, now, meta["name"], meta["symbol"], meta["image"],
                 json.dumps(meta["links"]) if meta["links"] else None, row["pair_created_at"], tok))
            await self.db.exec("INSERT INTO price_ticks (token_address, ts, source, price_usd, market_cap, liquidity_usd, vol_h1) "
                               "VALUES (?,?,?,?,?,?,?)", (tok, now, "dexscreener", row["price_usd"],
                                                          row["market_cap"] or row["fdv"], row["liquidity_usd"], row["vol_h1"]))
        if best:
            rows = await self.db.all(TOKEN_SUMMARY_SQL + f" WHERE t.address IN ({','.join('?' * len(best))})", list(best))
            await hub.publish("tokens", rows)
            await self._hook("tokens", rows)

    # ---------- REST polls ----------
    async def _ensure_token(self, address: str, chain: str, name: str | None, symbol: str | None,
                            image: str | None, source: str, launched_at: float | None = None) -> None:
        now = time.time()
        existed = await self.db.one("SELECT 1 FROM tokens WHERE address=?", (address,))
        await self.db.exec(
            "INSERT INTO tokens (address, chain, name, symbol, image, source, first_seen, launched_at, updated) "
            "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(address) DO UPDATE SET "
            "name=COALESCE(tokens.name, excluded.name), symbol=COALESCE(tokens.symbol, excluded.symbol), "
            "image=COALESCE(tokens.image, excluded.image)",
            (address, chain, name, symbol, image, source, now, launched_at, now))
        if not existed and (name or symbol):
            await self._hook("new_token", {"address": address, "chain": chain, "name": name, "symbol": symbol, "source": source})

    async def _store_trending(self, source: str, lst: str, rows: list[dict[str, Any]], key: str = "token_address") -> None:
        now = time.time()
        await self.db.exec("DELETE FROM trending WHERE source=? AND list=?", (source, lst))
        await self.db.many("INSERT INTO trending (source, list, rank, token_address, pool_address, name, symbol, data_json, as_of) "
                           "VALUES (?,?,?,?,?,?,?,?,?)",
                           [(source, lst, i + 1, r.get(key), r.get("pool_address"), r.get("name") or r.get("question") or r.get("title"),
                             r.get("symbol"), json.dumps(r), now) for i, r in enumerate(rows)])
        await hub.publish("trending", {"source": source, "list": lst, "as_of": now, "rows": rows})

    async def poll_gecko_trending(self) -> None:
        rows = await self.gecko.trending_pools()
        self.trending_set = {r["token_address"] for r in rows if r["token_address"]}
        await self.mark_trending(self.trending_set)
        for r in rows:
            if r["token_address"]:
                await self._ensure_token(r["token_address"], "solana", r["name"], r["symbol"], r["image"],
                                         "geckoterminal", r["pool_created_at"])
                if r["token_address"] not in self.rug_pending:
                    self.queue_rug(r["token_address"], only_if_missing=True)
        await self._store_trending("geckoterminal", "trending", rows)

    async def poll_gecko_new(self) -> None:
        await self._store_trending("geckoterminal", "new", await self.gecko.new_pools())

    async def poll_dex_profiles(self) -> None:
        # rotate across the three 60 rpm endpoints
        self._rot = (getattr(self, "_rot", -1) + 1) % 5
        if self._rot in (3, 4):
            path = "/community-takeovers/latest/v1" if self._rot == 3 else "/ads/latest/v1"
            rows = await self.dex.http.get(path, dsx.profiles_bucket, not_found_ok=True) or []
            for r in rows:
                if r.get("tokenAddress"):
                    await self._ensure_token(r["tokenAddress"], r.get("chainId") or "solana", None, None, r.get("icon"), "dexscreener")
            await self._store_trending("dexscreener", "takeovers" if self._rot == 3 else "ads", [
                {"token_address": r.get("tokenAddress"), "chain": r.get("chainId"), "url": r.get("url"), "icon": r.get("icon"),
                 "description": (r.get("description") or "")[:200]} for r in rows])
            return
        if self._rot == 0:
            rows = await self.dex.profiles_latest()
            for r in rows:
                if r.get("tokenAddress"):
                    await self._ensure_token(r["tokenAddress"], r.get("chainId") or "solana", None, None, r.get("icon"), "dexscreener")
                    await self.db.exec("UPDATE tokens SET has_profile=1, links_json=COALESCE(links_json, ?) WHERE address=?",
                                       (json.dumps({"websites": [], "socials": r.get("links") or []}), r["tokenAddress"]))
            await self._store_trending("dexscreener", "profiles", [
                {"token_address": r.get("tokenAddress"), "chain": r.get("chainId"), "url": r.get("url"),
                 "icon": r.get("icon"), "description": (r.get("description") or "")[:200]} for r in rows])
        else:
            lst = "boosts_latest" if self._rot == 1 else "boosts_top"
            rows = await (self.dex.boosts_latest() if self._rot == 1 else self.dex.boosts_top())
            for r in rows:
                if r.get("tokenAddress"):
                    await self._ensure_token(r["tokenAddress"], r.get("chainId") or "solana", None, None, r.get("icon"), "dexscreener")
                    await self.db.exec("UPDATE tokens SET boost_amount=? WHERE address=?",
                                       (r.get("totalAmount") or r.get("amount"), r["tokenAddress"]))
            self.boosted_set = {r["tokenAddress"] for r in rows if r.get("tokenAddress")} | (self.boosted_set if self._rot == 2 else set())
            await self.mark_trending(self.boosted_set)
            await self._store_trending("dexscreener", lst, [
                {"token_address": r.get("tokenAddress"), "chain": r.get("chainId"), "url": r.get("url"),
                 "amount": r.get("amount"), "total_amount": r.get("totalAmount")} for r in rows])

    async def mark_trending(self, addrs: set[str]) -> None:
        """Remember the first time each coin reached a public trending/boost list — the yardstick for 'Radar saw it first'."""
        new = [a for a in addrs if a and a not in self.trending_seen]
        if not new:
            return
        self.trending_seen.update(new)
        now = time.time()
        await self.db.many("UPDATE tokens SET first_trending_at=COALESCE(first_trending_at, ?) WHERE address=?", [(now, a) for a in new])
        await self._hook("trending_first", {"addresses": new, "ts": now})

    async def _market(self, key: str, value: float | None, data: dict[str, Any] | None) -> None:
        if data is None:
            return
        row = {"key": key, "value": value, "source": data.get("source"), "as_of": data.get("as_of") or time.time(),
               "data_json": json.dumps(data)}
        await self.db.upsert("market", row, "key")
        await hub.publish("market", {"key": key, **data})

    async def poll_fear_greed(self) -> None:
        d = await self.market.fear_greed()
        await self._market("fear_greed", d and d["value"], d)

    async def poll_llama(self) -> None:
        d = await self.market.solana_dex_volume()
        await self._market("sol_dex_volume", d and d["total24h"], d)

    async def poll_cg_meme(self) -> None:
        d = await self.market.coingecko_meme_category()
        await self._market("meme_category", d and d["market_cap"], d)

    async def poll_cg_trending(self) -> None:
        await self._store_trending("coingecko", "trending", await self.market.coingecko_trending(), key="id")

    async def poll_polymarket(self) -> None:
        rows = await self.market.polymarket_top()
        await self._store_trending("polymarket", "top", rows, key="id")
        for m in rows:
            px, prev = m.get("last_price"), self.poly_prev.get(m["id"])
            if px is not None and prev is not None and abs(px - prev) >= 0.08:
                await self._hook("social", {"id": f"poly:{m['id']}:{int(time.time() // 300)}", "source": "polymarket",
                                            "author": "Polymarket", "text": f"Odds swing {prev * 100:.0f}% → {px * 100:.0f}%: {m['question']}",
                                            "url": m.get("url"), "ts": time.time(), "engagement": m.get("volume_24h") or 0,
                                            "tier_hint": "news"})
            if px is not None:
                self.poly_prev[m["id"]] = px

    GECKO_TO_DEX = {"solana": "solana", "base": "base", "bsc": "bsc", "eth": "ethereum", "arbitrum": "arbitrum", "polygon_pos": "polygon"}

    async def poll_gecko_other(self) -> None:
        for net in self.gecko_networks:
            if net == "solana":
                continue
            rows = await self.gecko.trending_pools(net)
            chain = self.GECKO_TO_DEX.get(net, net)
            for r in rows:
                if r["token_address"]:
                    await self._ensure_token(r["token_address"], chain, r["name"], r["symbol"], r["image"], "geckoterminal",
                                             r["pool_created_at"])
                    self.trending_set.add(r["token_address"])
            await self._store_trending("geckoterminal", f"trending_{net}", [{**r, "chain": chain} for r in rows])

    async def poll_jupiter_recent(self) -> None:
        rows = await self.extra.jupiter_recent()
        for r in rows:
            if r["token_address"]:
                await self._ensure_token(r["token_address"], "solana", r["name"], r["symbol"], r["icon"], "jupiter")
        await self._store_trending("jupiter", "recent", rows)

    async def poll_calendar(self) -> None:
        await self._store_trending("ff_calendar", "week", await self.extra.calendar(), key="title")

    async def poll_kalshi(self) -> None:
        await self._store_trending("kalshi", "top", await self.market.kalshi_top(), key="ticker")

    async def poll_feed(self, f: dict[str, Any]) -> None:
        now = time.time()
        fails, until = self.feed_backoff.get(f["name"], (0, 0.0))
        if until > now:
            return
        try:
            rows = await feeds.fetch(f["url"], f["name"], conditional=True)
        except Exception:
            # a dead or throttling feed backs off (1, 2, 4 ... 30 min) instead of hammering the publisher every cycle
            self.feed_backoff[f["name"]] = (fails + 1, now + min(1800, 60 * 2 ** fails))
            raise
        self.feed_backoff.pop(f["name"], None)
        fresh = []
        for r in rows:
            if await self.db.one("SELECT 1 FROM news WHERE id=?", (r["id"],)):
                continue
            if self.news_enricher:
                try:
                    r = self.news_enricher(r, f)
                except Exception as e:  # noqa: BLE001 - tagging must never drop a headline
                    log.debug("news enrich %s: %s", f["name"], e)
            await self.db.exec("INSERT OR IGNORE INTO news (id, source, title, link, published, fetched, grp, publisher, story_id, "
                               "tags_json, metas_json, tickers_json, sentiment, impact) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               (r["id"], r["source"], r["title"], r["link"], r["published"], r["fetched"], f.get("group"),
                                r.get("publisher"), r.get("story_id"), json.dumps(r.get("tags") or []),
                                json.dumps(r.get("metas") or []), json.dumps(r.get("tickers") or []), r.get("sentiment"),
                                r.get("impact")))
            fresh.append({**r, "group": f.get("group"), "detected": detect(r["title"])})
            src = {"reddit": "reddit", "trends": "google_trends"}.get(f.get("group") or "", "rss")
            await self._hook("social", {"id": f"rss:{r['id']}", "source": src, "author": f["name"], "text": r["title"],
                                        "url": r["link"], "ts": r["published"] or r["fetched"], "engagement": 0,
                                        "tier_hint": "news" if src in ("rss", "google_trends") else None, "group": f.get("group")})
        if fresh:
            await hub.publish("news", fresh)
            await self._hook("news", fresh)

    # ---------- safety ----------
    def queue_rug(self, mint: str, only_if_missing: bool = False) -> None:
        if mint in self.rug_pending:
            return
        self.rug_pending.add(mint)
        self.rug_queue.put_nowait(f"{'?' if only_if_missing else ''}{mint}")

    async def rug_worker(self) -> None:
        while True:
            item = await self.rug_queue.get()
            mint = item.lstrip("?")
            try:
                cur = await self.db.one("SELECT as_of FROM safety_reports WHERE token_address=?", (mint,))
                fresh = cur and time.time() - cur["as_of"] < settings.rugcheck_cache_s
                if not (fresh or (item.startswith("?") and cur)):
                    tok = await self.db.one("SELECT chain FROM tokens WHERE address=?", (mint,))
                    chain = (tok or {}).get("chain") or ("solana" if not mint.startswith("0x") else "ethereum")
                    rep = await (self.rug.report(mint) if chain == "solana" else self.extra.evm_safety(chain, mint))
                    if rep:
                        await self.db.upsert("safety_reports", rep, "token_address")
                        await hub.publish("safety", {**rep, "risks": json.loads(rep["risks_json"])})
                        await self._hook("safety", rep)
                        await self.db.exec("INSERT INTO holder_snapshots (token_address, ts, holders, top10_pct, source) VALUES (?,?,?,?,?)",
                                           (mint, rep["as_of"], rep.get("holders"), rep.get("top10_pct"), rep.get("source")))
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.debug("rugcheck %s: %s", mint, e)
            finally:
                self.rug_pending.discard(mint)

    async def trade_subs_loop(self) -> None:
        while True:
            try:
                now = time.time()
                self.launch_watch = {k: v for k, v in self.launch_watch.items() if v > now}
                want: list[str] = list(hub.viewed_tokens()) + list(self.flash_tokens)
                # brand-new launches first (their first 90 s is what the sniper and Surreal trade on), then the rest by
                # how long they're watched — before, 6-hour holds and called coins pushed newborns past the cap
                self.born = {k: t for k, t in self.born.items() if now - t < 120}
                newborn = sorted(self.born, key=lambda k: -self.born[k])
                want += newborn
                nb = set(newborn)
                want += sorted((k for k in self.launch_watch if k not in nb), key=lambda k: -self.launch_watch[k])
                want += [r["address"] for r in await self.db.all("SELECT address FROM watchlist")]
                want += [r["address"] for r in await self.db.all(
                    "SELECT t.address FROM tokens t LEFT JOIN pairs p ON p.pair_address=t.best_pair "
                    "WHERE t.source='pumpportal' AND (t.graduated_at > ? OR t.first_seen > ?) "
                    "ORDER BY COALESCE(p.vol_m5,0) DESC LIMIT ?", (time.time() - 3600, time.time() - 600,
                                                                  settings.max_trade_subscriptions))]
                await self.pump.set_token_trades(list(dict.fromkeys(want)))
                if self.alt_task is not None and not self.alt_task.done():       # mirror onto the fallback trade feed
                    await self.alt.set_token_trades(list(dict.fromkeys(want)))
                    if self.alt.account_subs != self.pump.account_subs:
                        await self.alt.set_account_trades(set(self.pump.account_subs))
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.debug("trade subs: %s", e)
            self.subs_kick.clear()
            try:   # wake early when someone opens a token, so its chart goes live within a second
                await asyncio.wait_for(self.subs_kick.wait(), timeout=10)
            except asyncio.TimeoutError:
                pass

    async def trade_feed_loop(self) -> None:
        """Keep a live trade feed no matter what: if PumpPortal delivers no trades while launches keep arriving, run the
        on-chain feed (Helius / Solana RPC logs); once PumpPortal trades flow again, stop it to save CPU."""
        started = time.time()
        while True:
            await asyncio.sleep(5)
            try:
                await self.feed_check(time.time(), started)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                log.warning("trade feed loop: %s", e)

    async def feed_check(self, now: float, started: float) -> str:
        import os
        mode = os.environ.get("CHAIN_TRADES", "auto")      # auto | on | off
        pp = self.pump.trade_rate(90)
        launches = sum(1 for t in self.born.values() if now - t < 90)
        running = self.chain_task is not None and not self.chain_task.done()
        # no PumpPortal key = PumpPortal will never stream trades: start the chain feed as soon as launches arrive
        grace = 0 if not self.pump.has_key else 40
        need = mode == "on" or (mode == "auto" and now - started > grace and pp == 0 and launches > 0)
        if need and not running:
            log.warning("trade feed: PumpPortal delivered %d trades in 90s for %d new launches — starting the on-chain "
                        "trade feed (%s) and the alternate feed (%s)", pp, launches, self.chain.url.split("?")[0], self.alt.url)
            self.chain._stop = False
            self.chain_task = asyncio.get_running_loop().create_task(self.chain.run())
            if os.environ.get("PUMP_ALT_WS_URL", "x") and (self.alt_task is None or self.alt_task.done()):
                self.alt._stop = False
                self.alt.token_subs, self.alt.account_subs = set(self.pump.token_subs), set(self.pump.account_subs)
                self.alt_task = asyncio.get_running_loop().create_task(self.alt.run())
            self._start_extras()
            self.chain_since = now
            return "started"
        if running and mode != "on" and (mode == "off" or (pp > 30 and now - self.chain_since > 300)):
            log.warning("trade feed: PumpPortal trades are flowing — stopping the fallback feeds")
            for feed in (self.chain, self.alt, *self.extras):
                feed.stop()
                if feed.ws is not None:
                    await feed.ws.close()
            self.extra_tasks = {}
            return "stopped"
        on_helius = "helius" in self.chain.url and self.chain.ws is not None
        if running and on_helius and self.extra_tasks:                  # Helius sees the whole tape: the public extras are redundant
            for feed in self.extras:
                feed.stop()
                if feed.ws is not None:
                    await feed.ws.close()
            self.extra_tasks = {}
        elif running and not on_helius:                                 # public RPC (no key, or the Helius key keeps failing)
            self._start_extras()
        return "running" if running else "idle"

    def _start_extras(self) -> None:
        import os
        if os.environ.get("SOLANA_WS_URL"):
            return
        for i, feed in enumerate(self.extras):
            if i not in self.extra_tasks or self.extra_tasks[i].done():
                feed._stop = False
                self.extra_tasks[i] = asyncio.get_running_loop().create_task(feed.run())

    def feed_status(self) -> dict[str, Any]:
        running = self.chain_task is not None and not self.chain_task.done()
        alt_running = self.alt_task is not None and not self.alt_task.done()
        return {"pumpportal_key": self.pump.has_key, "pumpportal_trades_90s": self.pump.trade_rate(90),
                "pumpportal_est_cost_sol_today": self.pump.est_cost_sol_today(), "pumpportal_budget_sol": self.pump.budget_sol,
                "pumpportal_paused_for_budget": self.pump.saving, "pumpportal_says": self.pump.notices[:4], "chain_running": running, "chain": self.chain.snapshot(),
                "extras": [self.extras[i].snapshot() for i, t in self.extra_tasks.items() if not t.done()],
                "decoded_per_min": self.chain.rate(60, self.chain.recent_dec) + sum(f.rate(60, f.recent_dec) for f in self.extras),
                "alt_running": alt_running, "alt": {"endpoint": self.alt.url, "connected": self.alt.ws is not None,
                                                    "trades_90s": self.alt.trade_rate(90)}}

    async def prune(self) -> None:
        cut = time.time() - settings.retention_hours * 3600
        await self.db.exec("DELETE FROM price_ticks WHERE ts < ?", (cut,))
        await self.db.exec("DELETE FROM pump_trades WHERE ts < ?", (cut,))
        await self.db.exec("DELETE FROM api_usage WHERE ts < ?", (cut,))
        await self.db.exec("DELETE FROM news WHERE fetched < ?", (cut,))
        for table, col in (("social_events", "ts"), ("wallet_trades", "ts"), ("alerts", "ts"), ("holder_snapshots", "ts")):
            await self.db.exec(f"DELETE FROM {table} WHERE {col} < ?", (cut,))
        await self.db.exec("DELETE FROM narratives WHERE last_seen < ?", (cut,))
        await self.db.exec("DELETE FROM narrative_tokens WHERE narrative_id NOT IN (SELECT id FROM narratives)")
        await self.db.exec("DELETE FROM tokens WHERE first_seen < ? AND best_pair IS NULL AND address NOT IN (SELECT address FROM watchlist)",
                           (time.time() - 24 * 3600,))

    async def token_summary(self, address: str) -> dict[str, Any] | None:
        return await self.db.one(TOKEN_SUMMARY_SQL + " WHERE t.address=?", (address,))
